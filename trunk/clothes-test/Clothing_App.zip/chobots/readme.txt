1) Download Adobe AIR (It's Free from Adobe.com)
2) Open clothes-test.air (Found in clothes-test folder)
3) Set the Address by clicking "..." and select the "chobots" folder
4) Press "refresh"
5) Close the app
6) Open the app

Note: Place your .swf clothing files in "clothes/flash-resources"